      _   _      ____  _ __   __
     | \ | | ___|  _ \| |\ \ / /_  __
     |  \| |/ _ \ |_) | __\ V /\ \/ /
     | |\  |  __/  __/| |_ | |  >  <
     |_| \_|\___|_|    \__||_| /_/\_\

Este repositorio esta hecho con fines educativos
e informativos cualquier mal uso que se le de el
creador no se hace responsable del uso cada quien
es responsable de sus acciones.

Al escribir el nombre de la empresa o persona
deben de ir separados por un %20 ejemplo:

Fernando%20Enrique%20Barnochoa

Si es patente se escribe junta por ejemplo:

ABCG23

Y si es un rut tiene que tener este formato:

21.671.395-9


Gracias por usar Doxrut!!
