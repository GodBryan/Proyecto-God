apt install w3m -y
bash Doxrut.sh
